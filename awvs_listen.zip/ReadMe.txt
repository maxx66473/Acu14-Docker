1、将wvsc文件放置于/home/acunetix/.acunetix/v_210503151/scanner/目录，与原文件进行替换；
2、将license_info.json、wa_data.dat文件设置444权限，命令：[ chmod 444 license_info.json & chmod 444 wa_data.dat ]；
3、将license_info.json、wa_data.dat文件放置于/home/acunetix/.acunetix/data/license/目录，与原文件进行替换。
